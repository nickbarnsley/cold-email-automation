export interface IndustryPrompts {
  contextPrompt: string;
  backupPersonalization: string;
  painPoints: string[];
  valueProps: string[];
}

export const industryPrompts: { [key: string]: IndustryPrompts } = {
  electricians: {
    contextPrompt: `You are researching an electrical contractor business. Look at their website, social media, and any available information to find:

1. Types of electrical services they offer (residential, commercial, industrial)
2. Service areas and locations they cover
3. Years in business or experience level
4. Any specializations (smart home, solar, emergency services)
5. Current projects or recent work showcased
6. Team size or if it's a solo operation
7. Any certifications or licenses mentioned
8. Technology or equipment they use

Focus on finding specific details that show their expertise and current business situation.`,

    backupPersonalization: `I noticed you provide electrical services in [CITY]. Many electrical contractors in your area are struggling with consistent lead generation while dealing with rising material costs and increased competition from larger firms.

I help electrical contractors like yourself generate 15-30 qualified leads per month through targeted outreach to homeowners and businesses who actually need electrical work - not just anyone with a pulse.

Worth a quick conversation to see if this could help your business?`,

    painPoints: [
      'Inconsistent lead flow between busy and slow seasons',
      'Rising material and equipment costs eating into profits',
      'Difficulty finding qualified electricians to hire',
      'Competition from larger electrical companies',
      'Time spent on administrative work vs. actual electrical work',
      'Getting paid on time by commercial clients',
      'Keeping up with changing electrical codes and regulations'
    ],

    valueProps: [
      'Consistent monthly lead generation',
      'Higher profit per job through better client targeting',
      'Automated follow-up systems',
      'Focus on high-value electrical projects',
      'Build relationships with repeat commercial clients'
    ]
  },

  plumbers: {
    contextPrompt: `You are researching a plumbing business. Look at their website, social media, and any available information to find:

1. Types of plumbing services (residential, commercial, emergency)
2. Service radius and coverage areas
3. Years in business and experience
4. Specializations (drain cleaning, water heaters, repiping, etc.)
5. Emergency service availability (24/7, weekends)
6. Recent projects or customer testimonials
7. Size of operation (solo, small team, large company)
8. Equipment and technology used
9. Licensing and insurance information

Look for specific details about their current business focus and expertise areas.`,

    backupPersonalization: `I saw you provide plumbing services in [CITY]. Most plumbers I work with are dealing with the same challenges - emergency calls disrupting scheduled jobs, seasonal fluctuations in revenue, and too much time spent on small repair jobs instead of higher-value installations.

I help plumbing contractors generate consistent leads for water heater replacements, repiping jobs, and other high-value services that actually move the needle on your revenue.

Would it make sense to have a brief conversation about how this could work for your business?`,

    painPoints: [
      'Emergency calls disrupting scheduled work',
      'Low-margin repair jobs taking up too much time',
      'Seasonal fluctuations in demand',
      'Competition from large franchise operations',
      'Difficulty pricing jobs accurately',
      'Finding reliable plumbers to hire',
      'Dealing with insurance claims and warranty issues'
    ],

    valueProps: [
      'Focus on high-value installation jobs',
      'Predictable monthly revenue streams',
      'Less emergency calls, more planned work',
      'Better customer relationships',
      'Higher average job values'
    ]
  },

  dentists: {
    contextPrompt: `You are researching a dental practice. Look at their website, social media, and any available information to find:

1. Types of dental services offered (general, cosmetic, orthodontics, oral surgery)
2. Location and areas served
3. Years in practice or when practice was established
4. Practice size (solo practitioner, group practice, multiple locations)
5. Specializations or focus areas
6. Technology and equipment mentioned
7. Insurance acceptance and payment options
8. Patient demographics they serve
9. Any recent expansions or renovations
10. Community involvement or professional associations

Focus on understanding their practice philosophy and current business situation.`,

    backupPersonalization: `I noticed your dental practice in [CITY]. Many dental practices are struggling with patient acquisition costs rising while insurance reimbursements stay flat or decrease. Plus, there's increased competition from corporate dental chains and new practices opening regularly.

I help established dental practices like yours attract patients who actually value quality care and are willing to invest in their oral health - not just insurance-driven patients looking for the cheapest option.

Worth a quick call to see if this approach could work for your practice?`,

    painPoints: [
      'Rising patient acquisition costs',
      'Declining insurance reimbursements',
      'Competition from corporate dental chains',
      'No-shows and last-minute cancellations',
      'Staff turnover and hiring challenges',
      'Equipment costs and technology updates',
      'Managing patient expectations vs. insurance coverage'
    ],

    valueProps: [
      'Attract patients who value quality care',
      'Higher case acceptance rates',
      'Reduced dependence on insurance',
      'More predictable appointment scheduling',
      'Build long-term patient relationships'
    ]
  },

  lawyers: {
    contextPrompt: `You are researching a law firm or attorney. Look at their website, social media, and any available information to find:

1. Practice areas and legal specializations
2. Years of experience and bar admissions
3. Firm size (solo, small firm, large firm)
4. Client types (individuals, businesses, government)
5. Geographic areas served
6. Notable cases or achievements
7. Professional associations and certifications
8. Fee structure or billing approach
9. Technology and case management systems
10. Community involvement or thought leadership

Focus on understanding their legal expertise and current business development efforts.`,

    backupPersonalization: `I saw your law practice in [CITY]. Most attorneys I work with are facing the same challenges - traditional referral sources drying up, increased competition from larger firms, and difficulty standing out in a crowded market.

I help law firms like yours generate qualified leads for [PRACTICE AREA] cases through targeted outreach to people and businesses who actually need legal services right now - not just general brand awareness.

Worth a brief conversation to see if this could help grow your practice?`,

    painPoints: [
      'Traditional referral sources declining',
      'Competition from larger law firms',
      'Difficulty differentiating in crowded market',
      'Client payment issues and collection',
      'Time spent on business development vs. legal work',
      'Rising overhead and operational costs',
      'Keeping up with legal technology changes'
    ],

    valueProps: [
      'Consistent qualified lead generation',
      'Higher-value client acquisition',
      'Reduced dependence on referrals',
      'More predictable revenue streams',
      'Focus on profitable practice areas'
    ]
  },

  contractors: {
    contextPrompt: `You are researching a general contractor or construction company. Look at their website, social media, and any available information to find:

1. Types of construction projects (residential, commercial, remodeling)
2. Service areas and project locations
3. Years in business and experience
4. Project size range (small repairs to large builds)
5. Specializations (custom homes, renovations, commercial)
6. Recent projects and portfolio
7. Team size and subcontractor relationships
8. Licensing and insurance information
9. Equipment and capabilities
10. Awards or industry recognition

Look for details about their current project focus and business capacity.`,

    backupPersonalization: `I noticed your construction company in [CITY]. Most contractors are dealing with the same frustrations - feast or famine project flow, clients shopping purely on price, and too much time spent chasing down leads that never convert.

I help construction companies like yours get in front of property owners who are actively planning projects and have realistic budgets - not just people getting free quotes with no intention to build.

Makes sense to have a quick conversation about how this could help stabilize your project pipeline?`,

    painPoints: [
      'Inconsistent project pipeline',
      'Clients shopping purely on price',
      'Material cost fluctuations',
      'Difficulty finding skilled workers',
      'Long sales cycles and unpredictable closing',
      'Competition from unlicensed contractors',
      'Managing multiple projects simultaneously'
    ],

    valueProps: [
      'Consistent project pipeline',
      'Qualified leads with realistic budgets',
      'Shorter sales cycles',
      'Higher-margin projects',
      'Better client relationships'
    ]
  },

  restaurants: {
    contextPrompt: `You are researching a restaurant or food service business. Look at their website, social media, and any available information to find:

1. Type of cuisine and dining style
2. Location and hours of operation
3. Years in business or when opened
4. Dining options (dine-in, takeout, delivery, catering)
5. Special features (private dining, events, outdoor seating)
6. Menu highlights and pricing range
7. Awards or recognition received
8. Community involvement or partnerships
9. Recent updates or renovations
10. Online reviews and customer feedback trends

Focus on understanding their current business model and market position.`,

    backupPersonalization: `I saw your restaurant in [CITY]. The restaurant industry has been incredibly challenging lately - rising food costs, staff shortages, and customers being more selective about dining out.

I help restaurants like yours fill seats during slower periods and build a loyal customer base that comes back regularly - not just one-time diners chasing deals.

Worth a quick conversation to see if this could help increase your regular customer traffic?`,

    painPoints: [
      'Rising food and labor costs',
      'Staff recruitment and retention',
      'Inconsistent customer traffic',
      'Competition from delivery apps',
      'Thin profit margins',
      'Seasonal fluctuations',
      'Managing online reviews and reputation'
    ],

    valueProps: [
      'Increase regular customer frequency',
      'Build loyal customer base',
      'Fill tables during slow periods',
      'Higher average ticket values',
      'Reduce dependence on third-party delivery'
    ]
  },

  'auto repair': {
    contextPrompt: `You are researching an automotive repair shop or service center. Look at their website, social media, and any available information to find:

1. Types of services offered (general repair, specialty work, inspections)
2. Vehicle types serviced (all makes, specific brands, age ranges)
3. Location and service area
4. Years in business and experience
5. Certifications and technician qualifications
6. Equipment and diagnostic capabilities
7. Warranty policies and guarantees
8. Customer service approach
9. Specializations (transmission, brakes, engine, etc.)
10. Fleet or commercial services

Look for details about their expertise and current business focus.`,

    backupPersonalization: `I noticed your auto repair shop in [CITY]. Most shop owners are dealing with cars getting more complex while customers shop around for the lowest price, plus it's getting harder to find qualified techs who can work on modern vehicles.

I help automotive shops like yours attract car owners who value quality work and understand that expertise costs more than quick fixes - people who become long-term customers instead of one-time bargain hunters.

Worth a brief call to see if this could help build your customer base?`,

    painPoints: [
      'Increasing vehicle complexity',
      'Shortage of qualified technicians',
      'Customers shopping purely on price',
      'High equipment and tool costs',
      'Competition from dealerships and chains',
      'Warranty claims and customer disputes',
      'Keeping up with new automotive technology'
    ],

    valueProps: [
      'Attract customers who value quality',
      'Build long-term customer relationships',
      'Higher average repair orders',
      'Reduced price competition',
      'More consistent work flow'
    ]
  },

  'medical practices': {
    contextPrompt: `You are researching a medical practice or healthcare facility. Look at their website, social media, and any available information to find:

1. Medical specialties and services offered
2. Location and areas served
3. Years in practice or when established
4. Practice size (solo, group, multi-location)
5. Patient demographics and focus areas
6. Insurance acceptance and payment options
7. Technology and medical equipment
8. Telemedicine or virtual care options
9. Hospital affiliations or partnerships
10. Community health involvement

Focus on understanding their practice philosophy and current patient care approach.`,

    backupPersonalization: `I noticed your medical practice in [CITY]. Many healthcare practices are struggling with the same issues - increased administrative burden, declining reimbursements, and difficulty attracting patients who aren't just shopping for the most convenient appointment.

I help medical practices like yours attract patients who value quality care and are committed to following treatment plans - not just patients looking for quick fixes or prescription refills.

Worth a quick conversation to see if this could help grow your practice with the right patients?`,

    painPoints: [
      'Declining insurance reimbursements',
      'Increased administrative burden',
      'Staff turnover and hiring challenges',
      'No-shows and appointment cancellations',
      'Competition from urgent care centers',
      'Technology and EMR costs',
      'Patient compliance and follow-through'
    ],

    valueProps: [
      'Attract committed, compliant patients',
      'Reduce no-shows and cancellations',
      'Build long-term patient relationships',
      'Focus on preventive care',
      'Improve patient outcomes'
    ]
  },

  accountants: {
    contextPrompt: `You are researching an accounting firm or CPA practice. Look at their website, social media, and any available information to find:

1. Services offered (tax prep, bookkeeping, auditing, consulting)
2. Client types (individuals, small business, corporations)
3. Years in practice and experience
4. Practice size and staff
5. Specializations or industry focus
6. Technology and software used
7. Seasonal vs. year-round services
8. Professional certifications and credentials
9. Fee structure and service approach
10. Geographic areas served

Focus on understanding their current client base and service offerings.`,

    backupPersonalization: `I saw your accounting practice in [CITY]. Most CPAs are dealing with the same challenges - clients who only show up during tax season, pressure to compete on price, and too much time spent on low-value data entry instead of strategic advisory work.

I help accounting firms like yours attract business clients who need year-round financial guidance and are willing to pay for strategic advice - not just clients looking for the cheapest tax preparation.

Worth a brief conversation to see if this could help transform your practice?`,

    painPoints: [
      'Seasonal revenue fluctuations',
      'Clients shopping on price only',
      'Too much low-value data entry work',
      'Staff retention during busy season',
      'Competition from tax prep chains',
      'Technology investment costs',
      'Keeping up with tax law changes'
    ],

    valueProps: [
      'Year-round client relationships',
      'Higher-value advisory services',
      'Predictable monthly revenue',
      'Clients who value expertise',
      'Less seasonal work stress'
    ]
  },

  'real estate agents': {
    contextPrompt: `You are researching a real estate agent or brokerage. Look at their website, social media, and any available information to find:

1. Areas and markets served
2. Property types (residential, commercial, luxury, etc.)
3. Years of experience in real estate
4. Brokerage affiliation and team size
5. Recent sales and listings
6. Specializations (first-time buyers, investors, relocation)
7. Marketing approach and technology used
8. Professional designations and certifications
9. Community involvement and local expertise
10. Client testimonials and success stories

Focus on understanding their market expertise and current business approach.`,

    backupPersonalization: `I noticed you're a real estate agent in [CITY]. The market has been incredibly challenging lately - inventory shortages, interest rate fluctuations, and buyers who are more hesitant than ever to make decisions.

I help real estate agents like you get in front of motivated buyers and sellers who are ready to move forward - not just people casually browsing online who may or may not be serious about buying or selling.

Makes sense to have a quick conversation about how this could help you close more deals in today's market?`,

    painPoints: [
      'Inconsistent lead quality from online sources',
      'Market volatility and uncertainty',
      'Increased competition from other agents',
      'Clients with unrealistic expectations',
      'Long sales cycles and deal fallouts',
      'Rising marketing and lead generation costs',
      'Keeping up with market changes and regulations'
    ],

    valueProps: [
      'Higher quality, motivated leads',
      'Shorter sales cycles',
      'Clients with realistic expectations',
      'More referrals from satisfied clients',
      'Consistent deal flow'
    ]
  }
};

export const getIndustryList = (): string[] => {
  return Object.keys(industryPrompts);
};