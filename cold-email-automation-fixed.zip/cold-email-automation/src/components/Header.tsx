import Link from 'next/link'
import { Mail } from 'lucide-react'

export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Mail className="w-8 h-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">
              Cold Email Automation
            </span>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link
              href="/city-generator"
              className="text-gray-600 hover:text-blue-600 transition-colors"
            >
              City Generator
            </Link>
            <Link
              href="/csv-filter"
              className="text-gray-600 hover:text-blue-600 transition-colors"
            >
              CSV Filter
            </Link>
            <Link
              href="/prompt-generator"
              className="text-gray-600 hover:text-blue-600 transition-colors"
            >
              Prompt Generator
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}