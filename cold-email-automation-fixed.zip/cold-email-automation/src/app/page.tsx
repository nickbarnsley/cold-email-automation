import Link from 'next/link'
import { MapPin, FileText, MessageSquare } from 'lucide-react'

export default function Home() {
  const tools = [
    {
      title: 'City List Generator',
      description: 'Generate formatted city lists for D7 Lead Finder based on state and industry',
      icon: MapPin,
      href: '/city-generator',
      color: 'bg-blue-500'
    },
    {
      title: 'D7 CSV Category Filter',
      description: 'Upload and filter D7 CSV files to extract relevant business categories',
      icon: FileText,
      href: '/csv-filter',
      color: 'bg-green-500'
    },
    {
      title: 'Clay Prompt Generator',
      description: 'Generate industry-specific prompts and personalization for Clay enrichment',
      icon: MessageSquare,
      href: '/prompt-generator',
      color: 'bg-purple-500'
    }
  ]

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900">
          Cold Email Automation Tools
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Professional list building tools for your cold email agency.
          Access these tools from anywhere to streamline your workflow.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {tools.map((tool) => {
          const Icon = tool.icon
          return (
            <Link
              key={tool.href}
              href={tool.href}
              className="group block p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-200"
            >
              <div className="space-y-4">
                <div className={`inline-flex p-3 rounded-lg ${tool.color} text-white`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-600">
                  {tool.title}
                </h3>
                <p className="text-gray-600">
                  {tool.description}
                </p>
              </div>
            </Link>
          )
        })}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <h2 className="text-2xl font-semibold text-gray-900 mb-4">How to Use</h2>
        <div className="grid md:grid-cols-3 gap-6 text-sm text-gray-600">
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">1. City List Generator</h3>
            <p>Enter a state name and industry to get a formatted list of cities ranked 101-400 by population, ready for D7 Lead Finder.</p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">2. CSV Category Filter</h3>
            <p>Upload your D7 CSV export to extract and filter unique business categories relevant to your target industry.</p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">3. Clay Prompt Generator</h3>
            <p>Generate industry-specific context and personalized lines for your Clay enrichment workflows.</p>
          </div>
        </div>
      </div>
    </div>
  )
}