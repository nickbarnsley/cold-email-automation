'use client'

import { useState } from 'react'
import { MapPin, Download, Copy, Check } from 'lucide-react'
import { usCities, stateAbbreviations } from '@/data/cities'

export default function CityGenerator() {
  const [state, setState] = useState('')
  const [industry, setIndustry] = useState('')
  const [generatedCities, setGeneratedCities] = useState<string[]>([])
  const [copied, setCopied] = useState(false)

  const generateCityList = () => {
    if (!state || !industry) return

    // Find state abbreviation
    const stateCode = stateAbbreviations[state] || state.toUpperCase()

    // Filter cities for the selected state, ranks 101-400
    const stateCities = usCities
      .filter(city =>
        (city.state.toLowerCase() === state.toLowerCase() ||
         city.stateCode.toLowerCase() === stateCode.toLowerCase()) &&
        city.rank >= 101 &&
        city.rank <= 400
      )
      .sort((a, b) => a.rank - b.rank)
      .map(city => `${city.name}, ${city.stateCode}`)

    setGeneratedCities(stateCities)
  }

  const copyToClipboard = async () => {
    const text = generatedCities.join('\\n')
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const downloadTxt = () => {
    const text = generatedCities.join('\\n')
    const blob = new Blob([text], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${industry}_${state}_cities.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const popularStates = [
    'California', 'Texas', 'Florida', 'New York', 'Pennsylvania',
    'Illinois', 'Ohio', 'Georgia', 'North Carolina', 'Michigan',
    'New Jersey', 'Virginia', 'Washington', 'Arizona', 'Tennessee'
  ]

  const popularIndustries = [
    'electricians', 'plumbers', 'dentists', 'lawyers', 'accountants',
    'real estate agents', 'contractors', 'restaurants', 'auto repair',
    'medical practices', 'veterinarians', 'chiropractors', 'optometrists',
    'insurance agents', 'financial advisors'
  ]

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <div className="inline-flex p-3 rounded-lg bg-blue-500 text-white">
          <MapPin className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">
          City List Generator
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Generate formatted city lists for D7 Lead Finder. Returns cities ranked 101-400 by population,
          formatted as &quot;City, ST&quot; ready for direct use.
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <label className="block text-sm font-medium text-gray-700">
              State Name
            </label>
            <input
              type="text"
              value={state}
              onChange={(e) => setState(e.target.value)}
              placeholder="e.g., New Jersey"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <div className="flex flex-wrap gap-2">
              {popularStates.map((stateName) => (
                <button
                  key={stateName}
                  onClick={() => setState(stateName)}
                  className="px-3 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded-full text-gray-700"
                >
                  {stateName}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="block text-sm font-medium text-gray-700">
              Industry
            </label>
            <input
              type="text"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              placeholder="e.g., electricians"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <div className="flex flex-wrap gap-2">
              {popularIndustries.map((ind) => (
                <button
                  key={ind}
                  onClick={() => setIndustry(ind)}
                  className="px-3 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded-full text-gray-700"
                >
                  {ind}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={generateCityList}
            disabled={!state || !industry}
            className="w-full md:w-auto px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed font-medium"
          >
            Generate City List
          </button>
        </div>
      </div>

      {generatedCities.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">
              Generated Cities ({generatedCities.length} cities)
            </h2>
            <div className="flex space-x-2">
              <button
                onClick={copyToClipboard}
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm"
              >
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? 'Copied!' : 'Copy All'}
              </button>
              <button
                onClick={downloadTxt}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </button>
            </div>
          </div>

          <div className="bg-gray-50 rounded-md p-4 max-h-96 overflow-y-auto">
            <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono">
              {generatedCities.join('\\n')}
            </pre>
          </div>

          <div className="mt-4 p-4 bg-blue-50 rounded-md">
            <h3 className="font-medium text-blue-900 mb-2">Usage Instructions:</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Copy the city list above</li>
              <li>• Paste directly into D7 Lead Finder&apos;s city field</li>
              <li>• These cities are ranked 101-400 by population for optimal targeting</li>
              <li>• Format is ready: &quot;City, ST&quot; - no additional formatting needed</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}