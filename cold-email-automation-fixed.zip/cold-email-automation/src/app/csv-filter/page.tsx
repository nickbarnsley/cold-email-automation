'use client'

import { useState } from 'react'
import { FileText, Upload, Download, Copy, Check, X } from 'lucide-react'
import Papa from 'papaparse'

interface CSVRow {
  [key: string]: string
}

export default function CSVFilter() {
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [categories, setCategories] = useState<string[]>([])
  const [filteredCategories, setFilteredCategories] = useState<string[]>([])
  const [industry, setIndustry] = useState('')
  const [copied, setCopied] = useState(false)

  // Industry-specific keywords for filtering
  const industryKeywords: { [key: string]: string[] } = {
    electricians: [
      'electric', 'electrical', 'electrician', 'wiring', 'lighting', 'power',
      'electrical contractor', 'electrical service', 'electrical repair'
    ],
    plumbers: [
      'plumb', 'plumbing', 'plumber', 'pipe', 'drain', 'water', 'sewer',
      'plumbing contractor', 'plumbing service', 'plumbing repair'
    ],
    dentists: [
      'dental', 'dentist', 'orthodont', 'oral', 'teeth', 'tooth', 'endodont',
      'periodon', 'dental clinic', 'dental office', 'dental practice'
    ],
    lawyers: [
      'law', 'legal', 'attorney', 'lawyer', 'counsel', 'advocate', 'jurist',
      'law firm', 'legal service', 'legal office'
    ],
    contractors: [
      'contractor', 'construction', 'building', 'remodel', 'renovation',
      'general contractor', 'construction company', 'building contractor'
    ],
    restaurants: [
      'restaurant', 'food', 'dining', 'cafe', 'bistro', 'grill', 'bar',
      'eatery', 'cuisine', 'kitchen', 'catering'
    ],
    'auto repair': [
      'auto', 'automotive', 'car', 'vehicle', 'repair', 'mechanic', 'garage',
      'auto repair', 'car service', 'automotive service'
    ],
    'medical practices': [
      'medical', 'clinic', 'doctor', 'physician', 'health', 'healthcare',
      'medical practice', 'medical office', 'medical center'
    ],
    accountants: [
      'account', 'accounting', 'accountant', 'bookkeep', 'tax', 'finance',
      'accounting firm', 'accounting service', 'tax service'
    ],
    'real estate': [
      'real estate', 'realtor', 'property', 'estate', 'broker', 'realty',
      'real estate agent', 'property management'
    ]
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0]
    if (uploadedFile && uploadedFile.type === 'text/csv') {
      setFile(uploadedFile)
    } else {
      alert('Please upload a valid CSV file')
    }
  }

  const processCSV = () => {
    if (!file) return

    setLoading(true)

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        const data = results.data as CSVRow[]

        // Extract unique categories
        // Look for common category column names
        const possibleCategoryColumns = ['category', 'categories', 'business_category', 'type', 'industry', 'classification']
        let categoryColumn = ''

        if (data.length > 0) {
          const headers = Object.keys(data[0])
          categoryColumn = possibleCategoryColumns.find(col =>
            headers.some(header => header.toLowerCase().includes(col))
          ) || headers.find(header =>
            header.toLowerCase().includes('category') ||
            header.toLowerCase().includes('type')
          ) || headers[0] // fallback to first column
        }

        const uniqueCategories = new Set<string>()

        data.forEach(row => {
          const categoryValue = row[categoryColumn]
          if (categoryValue && categoryValue.trim()) {
            // Split by common delimiters and clean
            const splitCategories = categoryValue.split(/[,;|]/)
            splitCategories.forEach(cat => {
              const cleaned = cat.trim()
              if (cleaned) {
                uniqueCategories.add(cleaned)
              }
            })
          }
        })

        const categoriesArray = Array.from(uniqueCategories).sort()
        setCategories(categoriesArray)
        setLoading(false)
      },
      error: (error) => {
        console.error('Error parsing CSV:', error)
        setLoading(false)
        alert('Error parsing CSV file')
      }
    })
  }

  const filterCategories = () => {
    if (!industry || categories.length === 0) return

    const keywords = industryKeywords[industry.toLowerCase()] || []

    const filtered = categories.filter(category => {
      const categoryLower = category.toLowerCase()
      return keywords.some(keyword =>
        categoryLower.includes(keyword.toLowerCase())
      )
    })

    setFilteredCategories(filtered)
  }

  const copyToClipboard = async () => {
    const text = filteredCategories.join('\\n')
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const downloadTxt = () => {
    const text = filteredCategories.join('\\n')
    const blob = new Blob([text], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${industry}_categories_filtered.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const resetProcess = () => {
    setFile(null)
    setCategories([])
    setFilteredCategories([])
    setIndustry('')
    setCopied(false)
  }

  const popularIndustries = [
    'electricians', 'plumbers', 'dentists', 'lawyers', 'contractors',
    'restaurants', 'auto repair', 'medical practices', 'accountants', 'real estate'
  ]

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <div className="inline-flex p-3 rounded-lg bg-green-500 text-white">
          <FileText className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">
          D7 CSV Category Filter
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Upload your D7 CSV export to extract and filter unique business categories
          relevant to your target industry. Perfect for Clay enrichment workflows.
        </p>
      </div>

      {/* Step 1: Upload CSV */}
      <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Step 1: Upload D7 CSV File
        </h2>

        {!file ? (
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <label className="cursor-pointer">
              <span className="text-lg font-medium text-gray-700">
                Click to upload CSV file
              </span>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
            <p className="text-gray-500 mt-2">
              Upload your D7 Lead Finder CSV export
            </p>
          </div>
        ) : (
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <FileText className="w-6 h-6 text-green-600" />
              <span className="font-medium text-gray-900">{file.name}</span>
            </div>
            <button
              onClick={resetProcess}
              className="text-red-600 hover:text-red-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        {file && (
          <div className="mt-4">
            <button
              onClick={processCSV}
              disabled={loading}
              className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed font-medium"
            >
              {loading ? 'Processing...' : 'Extract Categories'}
            </button>
          </div>
        )}
      </div>

      {/* Step 2: Select Industry */}
      {categories.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Step 2: Select Target Industry
          </h2>

          <div className="space-y-3">
            <label className="block text-sm font-medium text-gray-700">
              Industry Type
            </label>
            <input
              type="text"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              placeholder="e.g., electricians"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <div className="flex flex-wrap gap-2">
              {popularIndustries.map((ind) => (
                <button
                  key={ind}
                  onClick={() => setIndustry(ind)}
                  className="px-3 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded-full text-gray-700"
                >
                  {ind}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 p-4 bg-gray-50 rounded-md">
            <p className="text-sm text-gray-600">
              <strong>Found {categories.length} unique categories</strong> in your CSV file.
              Select an industry above to filter for relevant categories.
            </p>
          </div>

          <div className="mt-4">
            <button
              onClick={filterCategories}
              disabled={!industry}
              className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed font-medium"
            >
              Filter Categories
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Results */}
      {filteredCategories.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">
              Filtered Categories ({filteredCategories.length} found)
            </h2>
            <div className="flex space-x-2">
              <button
                onClick={copyToClipboard}
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm"
              >
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? 'Copied!' : 'Copy All'}
              </button>
              <button
                onClick={downloadTxt}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </button>
            </div>
          </div>

          <div className="bg-gray-50 rounded-md p-4 max-h-96 overflow-y-auto">
            <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono">
              {filteredCategories.join('\\n')}
            </pre>
          </div>

          <div className="mt-4 p-4 bg-green-50 rounded-md">
            <h3 className="font-medium text-green-900 mb-2">Usage Instructions:</h3>
            <ul className="text-sm text-green-800 space-y-1">
              <li>• Copy the filtered categories above</li>
              <li>• Paste into Clay as lookup values or enrichment parameters</li>
              <li>• These categories are pre-filtered for your target industry</li>
              <li>• Use for business type matching or category-based enrichment</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}