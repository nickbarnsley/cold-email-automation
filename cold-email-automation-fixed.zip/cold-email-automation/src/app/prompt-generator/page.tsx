'use client'

import { useState } from 'react'
import { MessageSquare, Copy, Check, Download, Lightbulb, Target, MessageCircle } from 'lucide-react'
import { industryPrompts, getIndustryList } from '@/data/prompts'

export default function PromptGenerator() {
  const [selectedIndustry, setSelectedIndustry] = useState('')
  const [contextCopied, setContextCopied] = useState(false)
  const [backupCopied, setBackupCopied] = useState(false)

  const industries = getIndustryList()
  const currentPrompts = selectedIndustry ? industryPrompts[selectedIndustry] : null

  const copyToClipboard = async (text: string, type: 'context' | 'backup') => {
    try {
      await navigator.clipboard.writeText(text)
      if (type === 'context') {
        setContextCopied(true)
        setTimeout(() => setContextCopied(false), 2000)
      } else {
        setBackupCopied(true)
        setTimeout(() => setBackupCopied(false), 2000)
      }
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const downloadPrompts = () => {
    if (!currentPrompts || !selectedIndustry) return

    const content = `Industry: ${selectedIndustry.toUpperCase()}

CONTEXT PROMPT FOR CLAY:
${currentPrompts.contextPrompt}

BACKUP PERSONALIZATION:
${currentPrompts.backupPersonalization}

COMMON PAIN POINTS:
${currentPrompts.painPoints.map(point => `• ${point}`).join('\\n')}

VALUE PROPOSITIONS:
${currentPrompts.valueProps.map(prop => `• ${prop}`).join('\\n')}

Generated on: ${new Date().toLocaleDateString()}`

    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${selectedIndustry}_clay_prompts.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <div className="inline-flex p-3 rounded-lg bg-purple-500 text-white">
          <MessageSquare className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">
          Clay Prompt Generator
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Generate industry-specific prompts for Clay enrichment and backup personalization lines.
          Crafted specifically for cold email outreach to maximize response rates.
        </p>
      </div>

      {/* Industry Selection */}
      <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Select Target Industry
        </h2>

        <div className="space-y-3">
          <label className="block text-sm font-medium text-gray-700">
            Industry Type
          </label>
          <select
            value={selectedIndustry}
            onChange={(e) => setSelectedIndustry(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="">Choose an industry...</option>
            {industries.map((industry) => (
              <option key={industry} value={industry}>
                {industry.charAt(0).toUpperCase() + industry.slice(1)}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {industries.slice(0, 6).map((industry) => (
            <button
              key={industry}
              onClick={() => setSelectedIndustry(industry)}
              className="px-3 py-1 text-sm bg-purple-100 hover:bg-purple-200 rounded-full text-purple-700"
            >
              {industry.charAt(0).toUpperCase() + industry.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Generated Prompts */}
      {currentPrompts && (
        <div className="space-y-6">
          {/* Context Prompt */}
          <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Target className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-semibold text-gray-900">
                  Clay Context Prompt
                </h2>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => copyToClipboard(currentPrompts.contextPrompt, 'context')}
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                >
                  {contextCopied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                  {contextCopied ? 'Copied!' : 'Copy'}
                </button>
              </div>
            </div>

            <div className="bg-gray-50 rounded-md p-4">
              <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono">
                {currentPrompts.contextPrompt}
              </pre>
            </div>

            <div className="mt-4 p-4 bg-blue-50 rounded-md">
              <h3 className="font-medium text-blue-900 mb-2">How to Use:</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Copy this prompt and paste it into Clay&apos;s enrichment field</li>
                <li>• Clay will use this to research prospects and gather relevant information</li>
                <li>• This creates personalized context for your outreach messages</li>
              </ul>
            </div>
          </div>

          {/* Backup Personalization */}
          <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <MessageCircle className="w-6 h-6 text-green-600" />
                <h2 className="text-xl font-semibold text-gray-900">
                  Backup Personalization Line
                </h2>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => copyToClipboard(currentPrompts.backupPersonalization, 'backup')}
                  className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm"
                >
                  {backupCopied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                  {backupCopied ? 'Copied!' : 'Copy'}
                </button>
              </div>
            </div>

            <div className="bg-gray-50 rounded-md p-4">
              <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                {currentPrompts.backupPersonalization}
              </pre>
            </div>

            <div className="mt-4 p-4 bg-green-50 rounded-md">
              <h3 className="font-medium text-green-900 mb-2">How to Use:</h3>
              <ul className="text-sm text-green-800 space-y-1">
                <li>• Use when Clay enrichment doesn&apos;t return enough specific information</li>
                <li>• Replace [CITY] with the prospect&apos;s actual city name</li>
                <li>• This fallback focuses on common industry pain points</li>
                <li>• Still personalized but doesn&apos;t require specific research</li>
              </ul>
            </div>
          </div>

          {/* Pain Points and Value Props */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
              <div className="flex items-center space-x-3 mb-4">
                <Lightbulb className="w-6 h-6 text-orange-600" />
                <h3 className="text-lg font-semibold text-gray-900">
                  Common Pain Points
                </h3>
              </div>
              <ul className="space-y-2 text-sm text-gray-700">
                {currentPrompts.painPoints.map((point, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <span className="text-orange-600 mt-1">•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
              <div className="flex items-center space-x-3 mb-4">
                <Target className="w-6 h-6 text-purple-600" />
                <h3 className="text-lg font-semibold text-gray-900">
                  Value Propositions
                </h3>
              </div>
              <ul className="space-y-2 text-sm text-gray-700">
                {currentPrompts.valueProps.map((prop, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <span className="text-purple-600 mt-1">•</span>
                    <span>{prop}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Download All */}
          <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  Download Complete Prompt Package
                </h3>
                <p className="text-gray-600 text-sm mt-1">
                  Get all prompts, pain points, and value props in a single text file
                </p>
              </div>
              <button
                onClick={downloadPrompts}
                className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
              >
                <Download className="w-4 h-4 mr-2" />
                Download All
              </button>
            </div>
          </div>

          {/* Usage Tips */}
          <div className="bg-purple-50 rounded-lg p-6 border border-purple-200">
            <h3 className="font-medium text-purple-900 mb-3">💡 Pro Tips for Maximum Results:</h3>
            <div className="grid md:grid-cols-2 gap-4 text-sm text-purple-800">
              <div>
                <h4 className="font-medium mb-2">Clay Enrichment:</h4>
                <ul className="space-y-1">
                  <li>• Use the context prompt exactly as written</li>
                  <li>• Allow 24-48 hours for thorough research</li>
                  <li>• Review results and customize further if needed</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Personalization:</h4>
                <ul className="space-y-1">
                  <li>• Always customize city names and specific details</li>
                  <li>• Combine with company-specific research when possible</li>
                  <li>• Test different pain points with your audience</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}