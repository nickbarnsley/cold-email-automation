# Cold Email Automation Tools

A professional web application for cold email list building automation, designed for remote access from any computer.

## Features

### 🏙️ City List Generator
- Input: State name + Industry (e.g., "New Jersey" + "electricians")
- Output: Formatted city list for D7 Lead Finder
- Cities ranked 101-400 by population, formatted as "City, ST"
- Integrates with demographics data for optimal targeting

### 📄 D7 CSV Category Filter
- Upload D7 CSV files for processing
- Extract unique business categories
- Filter for industry-relevant categories only
- Clean output ready for Clay integration

### 💬 Clay Prompt Generator
- Industry-specific context prompts for Clay enrichment
- Backup personalization lines for fallback scenarios
- Curated pain points and value propositions
- Professional templates for 10+ industries

## Tech Stack

- **Framework**: Next.js 14 with TypeScript
- **Styling**: Tailwind CSS
- **Deployment**: Vercel (free tier)
- **CSV Processing**: Papa Parse
- **Icons**: Lucide React

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

1. Clone the repository:
\`\`\`bash
git clone <repository-url>
cd cold-email-automation
\`\`\`

2. Install dependencies:
\`\`\`bash
npm install
\`\`\`

3. Run the development server:
\`\`\`bash
npm run dev
\`\`\`

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your GitHub repository to Vercel
3. Deploy with zero configuration
4. Access your app from any computer via the provided URL

### Manual Deployment

1. Build the application:
\`\`\`bash
npm run build
\`\`\`

2. Start the production server:
\`\`\`bash
npm start
\`\`\`

## Usage

### City List Generator
1. Enter a state name (e.g., "New Jersey")
2. Enter target industry (e.g., "electricians")
3. Generate formatted city list
4. Copy and paste directly into D7 Lead Finder

### CSV Category Filter
1. Upload your D7 CSV export
2. Select target industry
3. Review filtered categories
4. Copy results for Clay workflows

### Clay Prompt Generator
1. Select your target industry
2. Copy the context prompt for Clay enrichment
3. Use backup personalization when needed
4. Reference pain points and value props for messaging

## Project Structure

\`\`\`
src/
├── app/                    # Next.js app router pages
│   ├── city-generator/     # City list generation tool
│   ├── csv-filter/         # CSV processing tool
│   ├── prompt-generator/   # Clay prompt generation
│   ├── globals.css         # Global styles
│   ├── layout.tsx          # Root layout
│   └── page.tsx           # Home page
├── components/             # Reusable React components
│   └── Header.tsx         # Navigation header
├── data/                  # Static data and configurations
│   ├── cities.ts          # US cities database
│   └── prompts.ts         # Industry prompt templates
└── lib/                   # Utility functions
\`\`\`

## Features in Detail

### Responsive Design
- Mobile-friendly interface
- Professional styling with Tailwind CSS
- Optimized for various screen sizes

### Data Processing
- Client-side CSV parsing for security
- Efficient filtering algorithms
- Real-time preview of results

### Industry Coverage
- Electricians, Plumbers, Dentists
- Lawyers, Contractors, Restaurants
- Auto Repair, Medical Practices
- Accountants, Real Estate Agents

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is private and proprietary.

## Support

For questions or support, contact the development team.